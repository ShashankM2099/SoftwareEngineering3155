import pytest
from Invoice import Invoice
#Shashank Mondrati
#Student ID: 801026182

@pytest.fixture()
def products():
    products = {'Pen': {'qnt': 10, 'unit_price': 3.75, 'discount': 5},
                'Notebook': {'qnt': 5, 'unit_price': 7.5, 'discount': 10}}
    return products



@pytest.fixture()
def invoice():
    invoice = Invoice()
    return invoice


def test_CanCalucateTotalImpurePrice(invoice, products):
    result = invoice.totalImpurePrice(products)
    assert result == 75


def test_CanCalucateTotalDiscount(invoice, products):
    result = invoice.totalDiscount(products)
    assert result == 5.625


def test_CanCalucateTotalPurePrice(invoice, products):
   result = invoice.totalPurePrice(products)
   assert result == 69.38

def test_CanCalulateTax(invoice,products):
    result = invoice.calculate_Tax(products)
    assert result == 5.2035

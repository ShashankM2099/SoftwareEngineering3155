import math


class Invoice:

    def __init__(self):
        self.items = {}

    def addProduct(self, qnt, price, discount):
        self.items['qnt'] = qnt
        self.items['unit_price'] = price
        self.items['discount'] = discount
        return self.items

    def totalImpurePrice(self, products):
        total_impure_price = 0
        # Complete the missing part of this function here---------------------1
        # By adding multiplication of the amount and unit price of each product
        for item, attr in products.items():
            qnt = attr['qnt']
            up = attr['unit_price']
            ##disc = attr['discount']
            total_impure_price += up * qnt

        return total_impure_price

    def totalDiscount(self, products):
        total_discount = 0
        # Complete the missing part of this function here---------------------2
        # By adding multiplication of total price and discount of each product
        self.total_discount = total_discount
        for item, attr in products.items():
            qnt = attr['qnt']
            up = attr['unit_price']
            disc = attr['discount']
            total_discount += up * qnt * (disc / 100)
            # total_discount = math.ceil(round(total_discount,1))
            self.total_discount = total_discount

        return total_discount

    def totalPurePrice(self, products):
        total_pure_price = 0
        # Complete the missing part of this function here--------------------------3
        # By subtracting total price and total discount
        total_pure_price = self.totalImpurePrice(products) - self.totalDiscount(products)
        total_pure_price = round(total_pure_price, 2)
        return total_pure_price

    def calculate_Tax(self, products):
        calculate_tax = 0.0
        # Calculating tax using discount and unit price------------------------------4
        # self.calculate_tax = calculate_tax
        calculate_tax = self.totalPurePrice(products) * 0.075
        # calculating tax at 7.5%
        calculate_tax = round(calculate_tax, 4)

        return calculate_tax

    def inputAnswer(self, input_value):
        while True:
            userInput = input(input_value)
            if userInput in ['y', 'n']:
                return userInput
                break
            print("y or n! Try again.")

    def inputNumber(self, input_value):
        while True:
            try:
                userInput = float(input(input_value))
            except ValueError:
                print("Not a number! Try again.")
                continue
            else:
                return userInput
                break
